#ifndef _Course_HPP_
#define _Course_HPP_

#include <vector>
#include <string>

using namespace std;


// Course countains, a course id, name, and PreRequisites and Print Methods for all three attributes
class Course {
public:
    string id;
    string name;
    vector<string> PreReq;
// constructors
    Course();
    Course(string id, string name, vector<string> PreReq );
    ~Course();
// Print methods
    void PrintCourse();
    void Prerequisites();
};

Course::Course() {
    id = "";
    name = "";
    PreReq = {};
}

Course::Course(string nId, string nName, vector<string> nPreReq = {} )
{
    this->id=nId;
    this->name=nName;
    this->PreReq=nPreReq;
}

Course::~Course()
{
}

void Course::PrintCourse() {

    cout <<  this->id  << ", " << this->name;
    cout << endl;
}
void Course::Prerequisites() {

    cout << "Prerequisites: ";
    for (unsigned i = 0; i < PreReq.size() ; i++) {
         cout <<PreReq[i];
         if ( i+1 == PreReq.size()) {
            break;
         }
         else {
             cout << ", ";
         }
     }
     cout << endl;

}
// Structure for a node
struct Node
        {
        Course data;
        Node *left;
        Node *right;

        Node () {
                this->left = nullptr;
                this->right = nullptr;
        }
        Node(Course new_data){
            this->left = nullptr;
            this->right = nullptr;
            data = new_data;
        } 
    };

class BinaryCourseTree {

    private:
    void addNode(Node* node, Course nCourse);
    void InOrderSortPrint(Node* node);

    public:
    Node* root = nullptr;
    void Insert(Course nCourse);
    Course FindCourse(string course_Id);
    void PrintAll();

};

void BinaryCourseTree::Insert(Course nCourse) {
  
    // insert node at null if node is empty
    if (root == nullptr) {
          root = new Node(nCourse);
    } else {
        //**Continue donw branches if root is full
        this->addNode(root, nCourse);
    }     
};

void BinaryCourseTree::addNode(Node* node, Course new_Course) {

// if new course is smaller than left current node

    if (node!= nullptr && node->data.id.compare(new_Course.id)>0) {
        // if left node is empty insert node there.
        if (node->left == nullptr) {
            node->left = new Node(new_Course);
            return;
            // else left node is full check that node
        } else {
            this->addNode(node->left, new_Course);
        }
        // if new course is larger than current node
    } else if (node != nullptr && node->data.id.compare(new_Course.id)<0) {
            // if right node is empty insert node there
        if ( node->right == nullptr) {
            node->right = new Node(new_Course);
            return;
            // else right node is full then check versus that node
        } else {
            this->addNode(node->right, new_Course);
        }
    }
    //**TEST PRINTS
}

void BinaryCourseTree::PrintAll() {
    // verifys that root is not empty
    if ( root != nullptr) {
        InOrderSortPrint(root);
    } else {
        cout << "No Data in Tree" << endl << endl;
    }
}

void BinaryCourseTree::InOrderSortPrint(Node* node) {

    if (node != nullptr) {
        // left to right order, recursively
        // If left go left
        InOrderSortPrint(node->left);
        // if no left print
        node->data.PrintCourse();
        // if right go right
        InOrderSortPrint(node->right);
    }

};

Course BinaryCourseTree::FindCourse(string course_Id) {
    Node *current = root;
    // start w/ Root

    // while not empty, search down tree
    while ( current != nullptr) {
        if (current->data.id.compare(course_Id) == 0) {
            return current->data;
        // if ID is smaller go left otherwise go right.
        }else if (course_Id.compare(current->data.id) <0 ){
            current = current->left;
        } else {
            current = current->right;
        }
    }

    // No data is found return empty Coursefile
    Course NotFound;
     return NotFound;
}


#endif /*!_Course_HPP_*/
