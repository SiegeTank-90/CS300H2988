//============================================================================
// Name        : main.cpp
// Author      : C.J. CLINE
// Version     : 1.0
// Description : A demostation of binary tree data structure using a list of CompSci Course
//============================================================================


#include <iostream>
#include <fstream>
#include "Course.hpp"
#include "parser.hpp"


using namespace std;




// Main Program and Where the menu exists
int main() {
    // initilaize menu choice variable and data structure
    char choice = '0';
    BinaryCourseTree DataStructure;

    cout << "Welcome to the course planner." << endl << endl;

    // Loads until users selects exit (choice 9)
    while ( choice != '9') {

        cout << "\t 1. Load Data Structure." << endl;
        cout << "\t 2. Print Course List." << endl;
        cout << "\t 3. Print Course." << endl;
        cout << "\t 9. Exit." << endl << endl;

        cout << "What would you like to do? : " ;
        cin >> choice;
        cout << endl <<endl;
        switch (choice)
        {
        case '1':
            {
            // Parse data and place into Data Structure see parser.hpp
            string filename;
            cout << "Please enter your courses file :: Hint: CourseList.txt :: ";
            cin >> filename;
            DataStructure = MyFileParser( filename, DataStructure);
          
            }
            break;
        case '2':
           // Print Course using BinaryCourseTree Functions see Course.hpp
            cout << "Here is a sammple schedule : " << endl <<endl;          
            DataStructure.PrintAll();
            cout << endl;
            break;

        case '3': 
            // Find Course using BinaryCourse Tree Functions see  
            {
                string findCourseID = "";
                Course FoundCourse;
                cout << "What course whould you do you want to know about? :: ";
                cin >> findCourseID;
                cout << endl;
                FoundCourse = DataStructure.FindCourse(findCourseID);
                
                if (!FoundCourse.id.empty()) {
                    // Print Methods apart of course
                    FoundCourse.PrintCourse();
                    if (FoundCourse.PreReq.size() == 0 ){
                        cout << "No PreRequisites" << endl << endl;
                    } else {
                        FoundCourse.Prerequisites();
                        cout << endl;
                    }
                } else {
                    cout << findCourseID << " Could Not Be Found :: Hint Case Sensitive" << endl<< endl;
                }       
            }      
            break;

        case '9':
            // Exit case
            cout << "Thank you for using the course planner!" << endl << endl; 
            break;

        default:
            cout << choice << ": Is not a valid option." << endl << endl;
            break;
        }

    }

    return 0;
}


// 